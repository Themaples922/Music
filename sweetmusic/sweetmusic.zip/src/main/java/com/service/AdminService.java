package com.service;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author Rachel
 * @since 2021-12-9
 */
public interface AdminService {
    boolean veritypasswd(String username, String password);
}
